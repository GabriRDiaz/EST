This zip contains only the pdf. If you wish to see any other file such as the dataset, the Excel files or the scripts I created to treat the data, you can obtain those files here:

https://github.com/GabriRDiaz/EST

